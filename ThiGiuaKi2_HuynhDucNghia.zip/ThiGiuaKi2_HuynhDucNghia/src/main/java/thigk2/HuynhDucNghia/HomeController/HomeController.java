package thigk2.HuynhDucNghia.HomeController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import thigk2.HuynhDucNghia.Model.TheLoaiSanPham;
import thigk2.HuynhDucNghia.Service.TheLoaiService;

@Controller
@RequestMapping("/san-pham")	
public class HomeController {

    @Autowired
    private TheLoaiService theLoaiService;
    @GetMapping("/the-loai")
    public String listTheLoai(ModelMap model) {
        model.addAttribute("dsTheLoai", theLoaiService.getAllTheLoai());
        return "the-loai-list"; 
    }
    @GetMapping("/the-loai/{id}")
    public String listSanPhamByTheLoai(@PathVariable("id") Integer id, ModelMap model) {
        TheLoaiSanPham tl = theLoaiService.getTheLoaiById(id);
        if (tl != null) {
            model.addAttribute("tenTheLoai", tl.getTenTheLoai());
            model.addAttribute("dsSanPham", tl.getDanhSachSanPham());
        }
        return "san-pham-list"; 
    }
}